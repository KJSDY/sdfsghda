const Launcher = require('minecraft-launcher-core');
const launcher = new Launcher();

const opts = {
  clientPackage: null,
  authorization: {
    access_token: '',
    client_token: '',
    uuid: '',
    name: 'Player', 
    user_properties: {}
  },
  root: "./minecraft",
  version: {
    number: "1.20.1",
    type: "release"
  },
  memory: {
    max: "2048M",
    min: "1024M"
  }
};

launcher.launch(opts);

launcher.on('debug', (e) => console.log(e));
launcher.on('error', (e) => console.log(e));
